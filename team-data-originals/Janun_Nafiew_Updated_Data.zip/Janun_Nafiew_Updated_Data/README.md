# JANUN Nafiew datasets

Start with reports/nafiew_final_summary.md. This is an integrated research draft, not a fully verified national inventory.

Use the six category CSVs as canonical services. national_service_directory.csv references them. Preserve service_id; join agency_id, group_id and source_id through the supporting tables. Do not count index rows as extra services.

Read schema.json for field/status conventions and sources/source_catalog.csv for evidence and limits. reports/nafiew_data_gap_report.csv lists unfinished work. Original supplied content is in original/.

Run the independent structural check:

```bash
python3 scripts/validate.py
```

For another extraction directory, pass --root /absolute/path/to/Janun_Nafiew_Updated_Data. The checker does not submit applications, access credentials, or make network requests.
