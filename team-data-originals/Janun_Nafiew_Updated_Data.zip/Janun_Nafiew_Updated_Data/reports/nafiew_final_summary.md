# JANUN — Nafiew integration report

Date: 2026-10-12. Status: researched draft with unresolved verification work.

The supplied archive contained one 39-page PDF and no CSVs, JSON schema, application files, configuration or another team member's machine-readable dataset. The original PDF and prompt are preserved. There was no existing CSV to extend or existing importer contract to test.

## Before and after

| Metric | Before | After |
| --- | ---: | ---: |
| CSV datasets inspected in supplied ZIP | 0 | — |
| Existing machine-readable service records | 0 | 60 |
| Baseline concrete Nafiew proposed IDs | 23 | 23 retained |
| Baseline group IDs | 4 | 4 retained outside service count |
| NID example ID owned by another workstream | 1 | 1 cross-reference |
| Narrative services/variants converted | — | 49 |
| Newly scoped researched services beyond the PDF's named list | — | 11 |
| Existing CSV records updated | 0 | 0 |
| Services with official source URL | — | 60 |
| Services fully verified | — | 0 |
| Services partially verified | — | 54 |
| Services awaiting verification | — | 6 |
| Human-reviewed services | — | 0 |
| Authority records | — | 24 |
| Portal records | — | 20 |
| Selected office listings | — | 5 |
| Hotline records | — | 6 |
| Source references / service-source relationships | — | 60 / 98 |

The 60 records retain the PDF's applicant/issue variants and separate materially different application actions. They are not 60 completely unrelated legal procedures. The national_service_directory is an index to canonical records; counting it again would double the service total. Office listings, fee components, sources and group headings are excluded.

Coverage: passport/travel 16; transport 12; tax 6; business 21; professional 3; national grievance 2.

## Work completed

Reconstructed proposed PASS/DL IDs split across PDF lines; retained all 28 proposed IDs through explicit mapping. Converted named narrative services into six canonical category files. Split broad business/professional headings into linked children without discarding parent IDs. Preserved 165 PDF hyperlink occurrences and 85 distinct normalized source targets, removing tracking/session components from the extracted reference dataset. Added selective official-source findings for vehicle services, document-type attestation, visas, migrant support, licence transition and fee components.

The source catalog distinguishes official page text, official indexed excerpts, inherited PDF-only references and retrieval errors. Indexed government information establishes limited facts; it does not prove the entire application flow or all current rules. Every service remains draft_human_review_pending. No human verifier/date was invented.

## Deduplication and integration

No confirmed duplicate service rows were removed. Twelve groups share an application gateway; they were reviewed and retained because the service action/applicant scope differs. Four broad headings are preserved as groups and excluded from service counts. NID correction and birth-registration referrals stay in cross_team_references; no parallel detailed records were created. Other members' CSVs were not present, so full cross-team deduplication remains impossible without their datasets.

## Remaining fields and link status

There are 234 blank cells across the six defined core fields: eligibility, required_documents, application_procedure, fee_information, processing_time and relevant_office_information. This is a literal blank count, not a declaration that every nonblank field is complete: explanatory fee/time text and limited source excerpts can still require verification. Optional appointment, office contact and tracking fields are excluded from this core count.

127 distinct URL targets were inventoried. 35 had direct retrieval attempts; 21 checked targets had no readable text, retrieval errors, availability-only notices or incomplete content. 92 targets were not directly checked. No target was established as permanently broken. A 404 after an earlier success, timeout or 502 is reported for follow-up rather than deleted. Login, OTP and CAPTCHA were not bypassed; no citizen credentials/records were collected. Individual DNCC licence records appearing in search were not used.

## Important unresolved research

Latest lost/stolen/damaged-passport primary circular; mission-specific charges and appointments; current BRTA professional totals, renewal/duplicate/retest rules and heavy-vehicle fees; mixed old/current NBR tax rates, return deadlines and VAT turnover thresholds; RJSC newer versus older name-clearance rates; BSTI renewal fee differences; full local trade-licence fees and municipal/union procedures; full office/ministry/service nationwide enumeration; professional registrations beyond the selected examples; current lending intake/terms; current dynamic disaster bulletins and cross-team IDs. See the gap report for each service and wider scope item.

Fire licence records use the confirmed 2026–27 re-assessment transition. The announced 2027-06-01 renewal opening is future guidance, not a currently available renewal feature. Generic information pages remain distinct from actual forms/gateways. The Bangladesh visa record is for foreign citizens entering Bangladesh.

## Schema and validation

Created a documented schema because none was supplied. Preserved proposed IDs, Bangla Unicode, category ordering and explicit relationships. CSVs use UTF-8 without BOM and quoted fields; numeric fees are stored separately with currency/source/status. Unknown amounts were not written as zero. canonical_file and source_id references are validated. This establishes internal consistency, not runtime compatibility with an unseen Janun importer.

The included validator checks CSV shape/UTF-8, mandatory fields, Bangla names, IDs/names, categories, dates, URL syntax, fee sign, verified-field presence, source/group/agency/related-service references, baseline ID retention and manifest integrity. The final ZIP is reopened, independently extracted, and validated again. See nafiew_validation_report.csv for structural results and unresolved warnings.

## Next review

Resolve high-priority fees/circulars, finish authority-specific checklists and offices, and assign a human editor before publication. nafiew_weekly_progress.csv is this run's initial snapshot; no recurring automation was created.

Final structural result: 26 CSV files authored. The independent validator checked 25 datasets (its own report excluded) with zero critical errors and 234 unresolved blank-field warnings. The validation report CSV was separately reparsed with every other CSV after ZIP extraction.
