import argparse, collections, csv, datetime, hashlib, io, json, pathlib, re, sys
from urllib.parse import urlsplit
p=argparse.ArgumentParser();p.add_argument('--root',type=pathlib.Path,default=pathlib.Path(__file__).resolve().parents[1]);p.add_argument('--json',type=pathlib.Path);a=p.parse_args()
root=a.root; reports=[]
def result(file,check,id,severity,outcome,correction=''):
 reports.append(dict(file_name=str(file),check_name=check,affected_record_id=id,severity=severity,result=outcome,recommended_correction=correction))
tables={}
for f in sorted(root.rglob('*.csv')):
 if f.name=='nafiew_validation_report.csv':continue
 rel=str(f.relative_to(root))
 try:
  text=f.read_bytes().decode('utf-8');raw=list(csv.reader(io.StringIO(text)))
  assert raw and len(set(raw[0]))==len(raw[0]) and all(raw[0])
  assert all(len(row)==len(raw[0]) for row in raw[1:])
  assert '�' not in text
  tables[rel]=list(csv.DictReader(io.StringIO(text)));result(rel,'csv_utf8_shape','', 'info','pass')
 except Exception as e:result(rel,'csv_utf8_shape','','critical','fail',str(e));continue
 for row in tables[rel]:
  rid=row.get('service_id',row.get('source_id',row.get('office_id','')))
  for key,val in row.items():
   if (key.endswith('_url') or key=='url') and val:
    u=urlsplit(val)
    if u.scheme not in ('http','https') or not u.netloc or any(c.isspace() for c in val):result(rel,'url_format',rid,'critical','fail',key)
   if key.endswith('_date') and val:
    try:datetime.date.fromisoformat(val)
    except ValueError:result(rel,'iso_date',rid,'critical','fail',key)
   if key=='amount' and val:
    try:assert float(val)>=0
    except (ValueError,AssertionError):result(rel,'fee_nonnegative',rid,'critical','fail',val)
   if re.search(r'jsessionid|utm_source=',val,re.I):result(rel,'url_tracking_cleanup',rid,'warning','review','Session/tracking value remains in CSV.')
canonical=['data/'+x+'_services.csv' for x in ('passport','transport','tax','business','professional','national')]
allservices=[]
mandatory=['service_id','service_name_bn','service_name_en','main_category','agency_id','source_url','verification_status']
core=['eligibility','required_documents','application_procedure','fee_information','processing_time','relevant_office_information']
for file in canonical:
 if file not in tables:result(file,'required_file','','critical','fail');continue
 for row in tables[file]:
  allservices.append(row)
  for field in mandatory:
   if not row.get(field):result(file,'mandatory_field',row.get('service_id',''),'critical','fail',field)
  if not re.search(r'[ঀ-৿]',row['service_name_bn']):result(file,'bangla_name',row['service_id'],'critical','fail')
  for field in core:
   if not row[field]:result(file,'missing_core_field',row['service_id'],'warning','unresolved',field)
  if row['verification_status'] not in ('partially_verified','awaiting_verification','fully_verified'):result(file,'verification_enum',row['service_id'],'critical','fail')
  if row['main_category'] not in ('passport_travel','transport','tax','business','professional','national'):result(file,'category_enum',row['service_id'],'critical','fail')
  if row['publication_status']!='draft_human_review_pending':result(file,'publication_gate',row['service_id'],'critical','fail')
  if row['verification_status']=='partially_verified' and not row['verified_fields']:result(file,'limited_verified_field_evidence',row['service_id'],'critical','fail')
  for field in row['verified_fields'].split(';'):
   if field and (field not in row or not row[field]):result(file,'verified_field_exists',row['service_id'],'critical','fail',field)
ids=[r['service_id'] for r in allservices];counts=collections.Counter(ids)
for id,n in counts.items():
 if n>1:result('canonical','duplicate_id',id,'critical','fail')
names=collections.defaultdict(list)
for r in allservices:names[(r['service_name_en'].casefold(),r['agency_id'],r['geographic_availability'])].append(r['service_id'])
for key,value in names.items():
 if len(value)>1:result('canonical','duplicate_name_agency_scope',';'.join(value),'warning','review')
sid=set(ids);agencyids={r['agency_id'] for r in tables.get('data/government_agencies.csv',[])};sourceids={r['source_id'] for r in tables.get('sources/source_catalog.csv',[])};groups={r['group_id'] for r in tables.get('data/service_groups.csv',[])}
for r in allservices:
 for key,target in [('agency_id',agencyids),('parent_group_id',groups),('related_service_id',sid)]:
  if r.get(key) and r[key] not in target:result('canonical','foreign_key',r['service_id'],'critical','fail',key)
relations=tables.get('sources/service_sources.csv',[])
for r in relations:
 if r['service_id'] not in sid or r['source_id'] not in sourceids:result('sources/service_sources.csv','foreign_key',r['service_id'],'critical','fail')
for id in sid:
 if not any(r['service_id']==id for r in relations):result('canonical','source_relationship',id,'critical','fail')
for r in tables.get('data/national_service_directory.csv',[]):
 if r['service_id'] not in sid or not (root/r['canonical_file']).exists():result('data/national_service_directory.csv','index_reference',r['service_id'],'critical','fail')
assert len(tables.get('data/national_service_directory.csv',[]))==len(sid)
for file,rows in tables.items():
 for row in rows:
  if 'source_id' in row and row['source_id'] and row['source_id'] not in sourceids:result(file,'source_foreign_key',row.get('service_id',''),'critical','fail')
  if 'agency_id' in row and row['agency_id'] and row['agency_id'] not in agencyids:result(file,'agency_foreign_key',row.get('service_id',''),'critical','fail')
  if file=='data/transport_fee_components.csv' and row['service_id'] not in sid:result(file,'service_foreign_key',row['service_id'],'critical','fail')
for file,key in [('data/government_agencies.csv','agency_id'),('data/government_portals.csv','portal_id'),('data/office_directory.csv','office_id'),('data/hotlines.csv','hotline_id'),('data/service_groups.csv','group_id'),('sources/source_catalog.csv','source_id'),('data/passport_fees.csv','fee_id'),('data/transport_fee_components.csv','fee_id')]:
 vals=[r[key] for r in tables.get(file,[])]
 if not all(vals) or len(vals)!=len(set(vals)):result(file,'primary_key_unique_nonempty','','critical','fail')
scheduleids={r['fee_schedule_id'] for file in ('data/passport_fees.csv','data/transport_fee_components.csv') for r in tables.get(file,[])}
for r in allservices:
 if r['fee_schedule_id'] and r['fee_schedule_id'] not in scheduleids:result('canonical','fee_schedule_foreign_key',r['service_id'],'critical','fail')
mapping=tables.get('sources/baseline_id_mapping.csv',[])
if len(mapping)!=28 or len({r['baseline_id'] for r in mapping})!=28:result('sources/baseline_id_mapping.csv','baseline_ids_preserved','','critical','fail')
if any(not r['source_url'] for r in allservices):result('canonical','source_url_coverage','','critical','fail')
manifest=root/'file_manifest.json'
if manifest.exists():
 for rel,expected in json.loads(manifest.read_text()).items():
  if hashlib.sha256((root/rel).read_bytes()).hexdigest()!=expected:result(rel,'file_hash','','critical','fail')
result('canonical','unique_service_count','','info',str(len(sid)))
result('canonical','no_critical_errors','','info','pass' if not any(r['severity']=='critical' for r in reports) else 'fail')
if a.json:a.json.write_text(json.dumps(reports,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'csv_files_checked':len(tables),'unique_service_records':len(sid),'critical_errors':sum(r['severity']=='critical' for r in reports),'warnings':sum(r['severity']=='warning' for r in reports)},ensure_ascii=False))
sys.exit(1 if any(r['severity']=='critical' for r in reports) else 0)
