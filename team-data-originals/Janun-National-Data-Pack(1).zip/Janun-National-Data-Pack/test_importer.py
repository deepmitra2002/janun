import importlib.util, pathlib, unittest
class ImporterTests(unittest.TestCase):
 def test_importer_exists(self):
  self.assertTrue(pathlib.Path(__file__).with_name('import_to_janun.py').exists(), 'A working importer must be delivered, not just a JSON file')
 def test_dry_run_validates_real_bundle_without_network(self):
  path=pathlib.Path(__file__).with_name('import_to_janun.py')
  if not path.exists(): self.skipTest('Importer not implemented')
  spec=importlib.util.spec_from_file_location('importer',path);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
  bundle=mod.load_bundle(path.with_name('janun-data.json'))
  self.assertGreaterEqual(len(bundle['services']),10)
  self.assertTrue(all(x['claims']['fees'] is None or isinstance(x['claims']['fees'],str) for x in bundle['services']))
 def test_apply_uses_existing_api_without_publishing(self):
  path=pathlib.Path(__file__).with_name('import_to_janun.py')
  if not path.exists(): self.skipTest('Importer not implemented')
  spec=importlib.util.spec_from_file_location('importer',path);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
  bundle=mod.load_bundle(path.with_name('janun-data.json'));record=bundle['services'][0]
  class Api:
   def __init__(self): self.calls=[];self.services=[];self.sources=[]
   def request(self,method,route,payload=None,**kw):
    self.calls.append((method,route))
    if route=='/api/admin/services' and method=='GET': return self.services.copy()
    if route=='/api/admin/sources' and method=='GET': return self.sources.copy()
    if route=='/api/admin/services':
     x={**payload,'id':'service1'};self.services.append(x);return x
    if route=='/api/admin/sources':
     x={**payload,'id':'source1','current_version':None,'versions':[]};self.sources.append(x);return {'id':'source1'}
    if route.endswith('/upload'):
     self.sources[0]['current_version']='version1';self.sources[0]['versions']=[{'id':'version1','content':kw['text']}];return {'id':'version1','status':'pending'}
    raise AssertionError(route)
  api=Api();mod.apply_bundle(api,{'services':[record]},interval=0)
  self.assertTrue(any(p.endswith('/upload') for _,p in api.calls))
  self.assertFalse(any('/review' in p or '/publish' in p for _,p in api.calls))
  before=len([1 for m,p in api.calls if m=='POST']);mod.apply_bundle(api,{'services':[record]},interval=0)
  self.assertEqual(before,len([1 for m,p in api.calls if m=='POST']))
if __name__=='__main__': unittest.main()
