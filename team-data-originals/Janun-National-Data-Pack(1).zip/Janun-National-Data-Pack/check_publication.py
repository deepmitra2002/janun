"""Read-only package gate; does not change or enforce the deployed Janun API."""
import json,pathlib,argparse

def blockers(r):
 p=r['provenance'];w=r['workflow'];b=list(w.get('blockers',[]))
 for k in ['human_verified_by','human_verified_on','cross_reviewer','cross_reviewed_on','approved_by','approved_on']:
  if not p.get(k):b.append('Missing '+k)
 if p.get('human_verified_by') and p.get('human_verified_by')==p.get('cross_reviewer'):b.append('Verifier and cross-reviewer must differ')
 if p.get('conflict_check_status')!='resolved':b.append('Conflict check incomplete')
 if w.get('status') not in ['verified','published']:b.append('Record not verified')
 if not w.get('publication_allowed'):b.append('Publication permission absent')
 if not r.get('publication_evidence',{}).get('required_fields_reviewed'):b.append('Required fields and jurisdiction review missing')
 if not r.get('publication_evidence',{}).get('current_official_sources_checked'):b.append('Current official evidence review missing')
 return list(dict.fromkeys(b))
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--file',default=str(pathlib.Path(__file__).with_name('service-master-v2.json')));a.add_argument('--report-only',action='store_true');args=a.parse_args()
 data=json.loads(pathlib.Path(args.file).read_text());out=[{'service_id':r['service_id'],'blockers':blockers(r)} for r in data['services']]
 blocked=sum(bool(r['blockers']) for r in out)
 print(json.dumps({'records':len(out),'blocked':blocked,'publishable':len(out)-blocked},indent=2))
 if not args.report_only and blocked:raise SystemExit(1)
