"""Import prepared data through Janun's existing authenticated admin API.
Default is validation only. Does not verify, publish, index, or overwrite records.
Python 3.9+, standard library only. Run against the Phase 2 API inspected for this pack.
"""
import argparse,getpass,http.cookiejar,json,pathlib,re,time,urllib.error,urllib.parse,urllib.request,uuid

def load_bundle(path):
 data=json.loads(pathlib.Path(path).read_text(encoding='utf-8'))
 if data.get('format')!='janun-service-data-v1':raise ValueError('Unsupported data format')
 slugs=set()
 for row in data['services']:
  s=row['service'];slug=s['slug']
  if not re.fullmatch(r'[a-z0-9]+(?:-[a-z0-9]+)*',slug) or slug in slugs:raise ValueError('Invalid or duplicate slug')
  slugs.add(slug)
  if row.get('review_status')!='needs_human_review':raise ValueError('Unexpected publication state')
  if set(row['claims'])!={'eligibility','documents','steps','fees','processing_time','deadline'}:raise ValueError('Claim fields do not match Janun')
  for key in ('eligibility','documents','steps'):
   if not isinstance(row['claims'][key],list) or len(row['claims'][key])>30:raise ValueError('Invalid claim list')
   if any(not isinstance(v,str) or not v.strip() or len(v)>1000 for v in row['claims'][key]):raise ValueError('Invalid claim item')
  for key in ('fees','processing_time','deadline'):
   v=row['claims'][key]
   if v is not None and (not isinstance(v,str) or len(v)>1000):raise ValueError('Invalid scalar claim')
  for url in [s['official_url'],row['source_upload']['url']]:
   p=urllib.parse.urlsplit(url)
   if p.scheme!='https' or not p.hostname or p.username or p.password:raise ValueError('Invalid source URL')
  if not row['source_upload']['content'].startswith('JANUN EDITORIAL'):raise ValueError('Missing synthesis provenance label')
 return data

class Api:
 def __init__(self,base,origin):
  p=urllib.parse.urlsplit(base)
  if p.username or p.password or p.query or p.fragment or p.path not in ('','/'):raise ValueError('Use an API origin without path or credentials')
  if p.scheme!='https' and not (p.scheme=='http' and p.hostname in ('localhost','127.0.0.1','::1')):raise ValueError('Remote API must use HTTPS')
  self.base=base.rstrip('/');self.origin=origin
  self.opener=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
 def request(self,method,route,payload=None,text=None):
  headers={'Origin':self.origin,'Accept':'application/json'};body=None
  if text is not None:
   boundary='janun'+uuid.uuid4().hex
   body=(f'--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="janun-summary.txt"\r\nContent-Type: text/plain; charset=utf-8\r\n\r\n'+text+f'\r\n--{boundary}--\r\n').encode()
   headers['Content-Type']='multipart/form-data; boundary='+boundary
  elif payload is not None:
   body=json.dumps(payload,ensure_ascii=False).encode();headers['Content-Type']='application/json'
  try:
   with self.opener.open(urllib.request.Request(self.base+route,data=body,headers=headers,method=method),timeout=45) as r:return json.load(r)
  except urllib.error.HTTPError as e:
   detail=e.read(1500).decode(errors='replace')
   raise RuntimeError(f'{method} {route}: HTTP {e.code}. {detail}. If 429, wait one minute and rerun; completed identical records are skipped.') from e

def apply_bundle(api,bundle,interval=13):
 services=api.request('GET','/api/admin/services');sources=api.request('GET','/api/admin/sources')
 if len(services)>=200 or len(sources)>=200:raise ValueError('API lists are capped at200. Stop to avoid incomplete duplicate checks; use a paginated importer for this installation.')
 existing={s['slug']:s for s in services};uploads=0
 for row in bundle['services']:
  if not row['import_enabled']:continue
  spec=row['service'];service=existing.get(spec['slug'])
  if service:
   if any(service.get(k)!=v for k,v in spec.items()):raise ValueError(f'Existing service differs: {spec["slug"]}. No overwrite attempted.')
  else:
   service=api.request('POST','/api/admin/services',spec);existing[spec['slug']]=service
  upload=row['source_upload']
  matches=[s for s in sources if s['service_id']==service['id'] and s['url']==upload['url'] and s['title']==upload['title']]
  if len(matches)>1:raise ValueError('Duplicate sources already exist; resolve them in Admin')
  src=matches[0] if matches else None
  if src and src.get('current_version'):
   versions=[v for v in src.get('versions',[]) if v['id']==src['current_version']]
   if not versions or versions[0]['content']!=upload['content']:raise ValueError('Existing source content differs; no version replaced')
   print('Already imported:',spec['slug']);continue
  if not src:
   src=api.request('POST','/api/admin/sources',{'service_id':service['id'],'url':upload['url'],'title':upload['title'],'agency':upload['agency']})
  if uploads and interval:time.sleep(interval)
  version=api.request('POST',f'/api/admin/sources/{src["id"]}/upload',text=upload['content']);uploads+=1
  print('Imported pending review:',spec['slug'],'version',version['id'])
 print('Finished. Nothing was verified or published. Claims remain in janun-data.json and source text for human review.')

def main():
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--file',default=str(pathlib.Path(__file__).with_name('janun-data.json')))
 parser.add_argument('--apply',action='store_true',help='Create draft services and pending source versions through the admin API')
 parser.add_argument('--base-url',default='http://localhost:8000')
 parser.add_argument('--origin',default='http://localhost:3000',help='Your frontend origin already permitted in ALLOWED_ORIGINS')
 args=parser.parse_args();data=load_bundle(args.file)
 print('Validated',len(data['services']),'records;',sum(r['import_enabled'] for r in data['services']),'enabled for import.')
 if not args.apply:print('Dry run only. Review README-BANGLA.md, then use --apply.');return
 api=Api(args.base_url,args.origin)
 api.request('POST','/api/admin/login',{'username':input('Janun admin username: '),'password':getpass.getpass('Janun admin password: ')})
 try:apply_bundle(api,data)
 finally:
  try:api.request('POST','/api/admin/logout',{})
  except Exception:pass
if __name__=='__main__':main()
