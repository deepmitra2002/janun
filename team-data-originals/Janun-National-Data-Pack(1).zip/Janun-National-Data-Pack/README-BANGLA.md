> আপডেট: আগে STANDARD-AUDIT-BANGLA.md পড়ুন। বর্তমান draft-import ৫৮টি; ১১টি বন্ধ। নতুন master-v2 সরাসরি importer-এ দেওয়া যাবে না।

# Janun-এ তথ্য যোগ করার নির্দেশনা

মোট 69 রেকর্ড: আগের ১২টি + নতুন 57টি। 58টি draft import-এর জন্য সক্রিয়; 11টি বন্ধ। ৩৫টি বিষয়েই অন্তত একটি রেকর্ড আছে, কিন্তু জাতীয়ভাবে পূর্ণ কভারেজ নয়।

## কোন ফাইল কী

- `DATA-BANGLA.md`: মানুষের পড়ার জন্য সংগৃহীত বাংলা তথ্য।
- `janun-data.json`: Janun-এর বর্তমান ServiceInput ও Claims কাঠামো অনুযায়ী ডেটা, উৎস, scope এবং সীমা।
- `source-texts/`: বর্তমান admin-এর text upload-এ ব্যবহারযোগ্য বাংলা সারসংক্ষেপ। এগুলো সরকারি মূল নথির হুবহু কপি নয়; উৎসসহ Janun-এর সম্পাদিত লেখা।
- `claims/`: প্রতিটি সেবার জন্য আলাদা JSON; Admin-এর structured claims editor-এ সরাসরি paste করার জন্য।
- `import_to_janun.py`: বর্তমান authenticated admin API দিয়ে bulk import; Python 3.9 বা নতুন হলেই চলে, নতুন Python package লাগে না।
- `required-source-hosts.txt`: বর্তমান SOURCE_HOSTS তালিকায় যোগ করার নির্দিষ্ট official host।

## ১. প্রস্তুতি

বর্তমান Janun Phase 2 backend চালু থাকতে হবে। Admin account এবং seeded categories থাকতে হবে। নতুন installation হলে project README অনুযায়ী migration, `python -m app.cli seed` এবং admin setup সম্পন্ন করুন। এই importer migration চালায় না।

Backend-এর `SOURCE_HOSTS` environment variable-এ বিদ্যমান host-গুলোর সঙ্গে `required-source-hosts.txt`-এর host-গুলো যোগ করুন। বিদ্যমান তালিকা মুছবেন না, wildcard ব্যবহার করবেন না। Backend restart করুন। এই সরকারি উৎসগুলো নতুন তথ্যের জন্য দরকার; বর্তমান default allowlist-এ সবগুলো নেই।

## ২. আগে যাচাই

ZIP extract করে তার folder-এ terminal খুলুন:

```bash
python import_to_janun.py
```

এতে শুধু JSON যাচাই হবে; server-এ কিছু লেখা হবে না।

## ৩. যোগ করুন

Local development-এর সাধারণ URL হলে:

```bash
python import_to_janun.py --apply --base-url http://localhost:8000 --origin http://localhost:3000
```

Hosted app হলে `--base-url`-এ backend-এর প্রকৃত HTTPS origin এবং `--origin`-এ ALLOWED_ORIGINS-এ থাকা frontend origin দিন। URL-এর শেষে `/api` যোগ করবেন না। Script admin username ও password চাইবে; password command history বা ফাইলে সংরক্ষণ করে না।

এতে service ও source text ডেটাবেসে যোগ হবে। এটি যাচাই বা প্রকাশ করে না। API-এর upload limit মানতে uploads-এর মাঝে ১৩ সেকেন্ড বিরতি থাকে; 57টি record-এ upload বিরতির জন্য প্রায় 13 মিনিট লাগতে পারে। মাঝপথে error হলে ঠিক করে একই command চালান: একই service/source content পুনরায় তৈরি করবে না। ভিন্ন existing content পেলে থামবে; overwrite করবে না। ২০০ বা তার বেশি service/source থাকলে API pagination সীমার কারণে importer থামে।

## ৪. Admin থেকে জনসাধারণের জন্য প্রকাশ

1. Admin → Sources-এ নতুন source খুলুন। Uploaded content-এ বাংলা তথ্য ও official links থাকবে।
2. মূল সরকারি উৎসের সঙ্গে তথ্য, scope ও তারিখ মিলিয়ে source-কে `review` করুন।
3. `claims/` থেকে সংশ্লিষ্ট সেবার JSON খুলে Admin-এর structured claims JSON editor-এ paste করুন। এতে eligibility, documents, steps, fees, processing_time ও deadline আছে। অনুপস্থিত তথ্য বানাবেন না। বর্তমান API pending অবস্থায় structured claims গ্রহণ করে না; এই অংশ verified করার সময় যুক্ত হয়।
4. যাচাই সম্পন্ন হলে source-কে `verified`, তারপর `published` করুন। এরপর সংশ্লিষ্ট service publish করুন। এগুলো বর্তমান Janun-এর review workflow।
5. Embedding configured থাকলে source index করুন। বর্তমান backend-এর keyword retrieval-এর জন্য embedding বাধ্যতামূলক নয়।

Import সফল হওয়া এবং জনসাধারণের chatbot-এ তথ্য চালু হওয়া আলাদা ধাপ। Script কাউকে মানব যাচাই হয়েছে বলে চিহ্নিত করে না। এটি live deployment-এ চালিয়ে দেওয়া হয়নি।

## দেশব্যাপী তথ্য কীভাবে থাকবে

একটি জাতীয় নিয়মের জন্য একই তথ্য ৬৪ বার কপি করার দরকার নেই। জাতীয় record-এ country=BD; DPDC-এর মতো record-এ provider-specific scope থাকবে। বর্তমান app-এ structured locality filtering নেই, তাই provider scope title, description ও source text-এও লেখা আছে। Metadata একা regional filtering চালু করে না।

এখনকার categories সীমিত বলে land-fee records `tax`, land/complaint records `legal`, utilities/agriculture `welfare`-এ রাখা হয়েছে। এটি বর্তমান app-এর সঙ্গে compatibility-এর জন্য; নতুন taxonomy বা UI redesign করা হয়নি।

## আরও ফাইল ও সীমা

- `coverage.json`: আপনার ৩৫ বিষয়ের সঙ্গে record-এর সম্পর্ক ও অসম্পূর্ণ অংশ।
- `geography.json`: ৮ বিভাগ ও ৬৪ জেলার নাম; index-only, সরকারি geocode নয়।
- `office-directory.json`: ২৩টি অফিস/যোগাযোগ এন্ট্রি; দেশব্যাপী পূর্ণ directory নয়।
- `provider-service-areas.json`: PGCL-এর প্রকাশিত অধিভুক্ত এলাকা।
- `research/`: বিস্তারিত গবেষণা ও claim-এর উৎস নির্দেশনা।
- `READ-FIRST.html`: ব্রাউজারে খোলার উপযোগী বাংলা সারসংক্ষেপ ও ফাইলের লিংক।

Geography, directory ও provider metadata বর্তমান importer নিজে app-এর আলাদা টেবিলে যোগ করে না। বর্তমান backend-এ structured locality filtering নেই। স্থানীয় তথ্যের scope title/source-এ আছে, তবু nationwide জনসাধারণের জন্য প্রকাশের আগে locality-aware retrieval লাগবে।

আমদানি draft তৈরি করে; প্রকাশের আগে পুরোনো স্থানীয় চার্টারের বর্তমানতা যাচাই করুন। `substantial` চিহ্নিত রেকর্ডও review ছাড়াই বর্তমান সরকারি নির্দেশনা নয়। `null` মানে তথ্য নেই—বিনামূল্যে বা সীমাহীন বোঝায় না।

বাকি: সব উপজেলার/ইউনিয়নের/ওয়ার্ডের অফিস-ঠিকানা ও বর্তমান fee schedules; সব বিদ্যুৎ প্রতিষ্ঠানের মাসিক বিল ও ownership workflow; অন্য WASA ও গ্যাস কোম্পানির পূর্ণ প্রক্রিয়া; চলতি সহায়তা কর্মসূচির intake, budget, deadline; আটকে থাকা মূল নথির পূর্ণ যাচাই। এগুলো কোনো নির্দিষ্ট ব্যক্তির জেলা চেয়ে নয়, দেশব্যাপী কর্তৃপক্ষ ধরে সংগ্রহ করতে হবে।

আগের ZIP import করে থাকলে পুরোনো ১২টি record অপরিবর্তিত থাকায় আবার তৈরি হবে না। নতুন রেকর্ডে একই বিষয়ের বিস্তারিত সংস্করণও আছে; review-এ পুরোনো সংক্ষিপ্ত record archive/একীভূত করার সিদ্ধান্ত নিন। Importer নিজে মুছবে না।
