"""Validate an extracted JANUN package using only Python's standard library."""
from pathlib import Path
import csv, hashlib, json, re, sys
from datetime import date
from urllib.parse import urlsplit

root=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parents[1]
summary=json.loads((root/'SUMMARY.json').read_text(encoding='utf-8'))
errors=[]
checks=[]
tables={}
def check(ok,message):
    (checks if ok else errors).append(message)

for p in sorted(root.glob('*.csv')):
    raw=p.read_bytes()
    check(raw.startswith(b'\xef\xbb\xbf'),p.name+': UTF-8 BOM')
    with p.open(encoding='utf-8-sig',newline='') as f:
        reader=csv.DictReader(f);headers=reader.fieldnames;rows=list(reader)
    tables[p.name]=rows
    check(bool(headers and rows),p.name+': nonempty table')
    check(all(None not in r and all(v is not None for v in r.values()) for r in rows),p.name+': rectangular CSV')
    ids=[r[headers[0]] for r in rows]
    check(all(ids) and len(ids)==len(set(ids)),p.name+': unique primary IDs')
    check(len(rows)==summary['csv_row_counts'].get(p.name),p.name+': reported row count')
    for i,r in enumerate(rows,1):
        for field,value in r.items():
            if not value:continue
            if field in ['checked_on','last_checked','next_verification','human_reviewed_on']:
                try:date.fromisoformat(value)
                except ValueError:errors.append(f'{p.name} row {i}: invalid date in {field}')
            if field in ['url','application_url','official_source_url','source_url','website','status_check_url','clean_url']:
                u=urlsplit(value)
                check(u.scheme in ['https','http'] and bool(u.netloc),f'{p.name} row {i}: URL {field}')
    check('\ufffd' not in raw.decode('utf-8-sig'),p.name+': no Unicode replacement glyphs')

source_ids={r['source_id'] for r in tables['sources.csv']}
record_ids={r['record_id'] for r in tables['programs.csv']}
office_ids={r['office_id'] for r in tables['local_offices.csv']}
gap_ids={r['gap_id'] for r in tables['data_gaps.csv']}
for name,rows in tables.items():
    for i,r in enumerate(rows,1):
        for field in ['sources','source_id','fee_source_id','processing_time_source_id','division_district_source_id','evidence_source_id']:
            if field in r and r[field]:
                check(set(r[field].split(';'))<=source_ids,f'{name} row {i}: source references {field}')
        if name!='programs.csv' and 'record_id' in r:
            check(r['record_id'] in record_ids,f'{name} row {i}: canonical record reference')
        if 'office_id' in r:check(r['office_id'] in office_ids,f'{name} row {i}: office reference')
        if 'gap_id' in r:check(r['gap_id'] in gap_ids,f'{name} row {i}: gap reference')
        if 'canonical_record_ids' in r:check(set(r['canonical_record_ids'].split(';'))<=record_ids,f'{name} row {i}: alias targets')
        if 'supports_records' in r and r['supports_records']:check(set(r['supports_records'].split(';'))<=record_ids,f'{name} row {i}: supported record targets')

originals={r['original_record_id'] for r in tables['original_records.csv']}
aliases={r['alias_id'] for r in tables['record_aliases.csv']}
check(originals==aliases,'All original proposed IDs retained in crosswalk')
check(len(originals)==summary['original_pdf_proposed_ids_retained'],'Original ID count agrees')
for r in tables['programs.csv']:
    check(bool(r['program_bn'] and r['program_en'] and r['authority'] and r['sources'] and r['checked_on']),r['record_id']+': required metadata')
    check(r['human_review_status']=='pending' and not r['human_reviewer'] and not r['human_reviewed_on'],r['record_id']+': human review not invented')
    if r['verification_status']=='verified_official':
        check(r['core_verified']=='true',r['record_id']+': verification scope explicitly checked')
        for field in ['fee','processing_time']:
            if r[field]:check(bool(r['fee_source_id' if field=='fee' else 'processing_time_source_id']),r['record_id']+': explicit amount/time evidence')
    if r['fee_verification']=='verified_official':check(bool(r['fee_source_id']),r['record_id']+': fee support required')
    if r['processing_time_verification']=='verified_official':check(bool(r['processing_time_source_id']),r['record_id']+': time support required')
check(any(re.search('[\u0980-\u09ff]',r['program_bn']) for r in tables['programs.csv']),'Bangla text preserved')
check(summary['canonical_services']==len(record_ids),'Canonical total agrees')
check(summary['fully_verified_services']==sum(r['verification_status']=='verified_official' for r in tables['programs.csv']),'Verified count agrees')
check(summary['gaps_resolved']==sum(r['status']=='resolved' for r in tables['data_gaps.csv']),'Resolved gap count agrees')
check(summary['unresolved_gap_tasks']==len(tables['remaining_data_collection_checklist.csv']),'Remaining task count agrees')
check(len(tables['geographic_coverage.csv'])==64,'All 64 districts have an explicit coverage status')
check(len(tables['local_offices.csv'])==summary['office_entries'],'Office total agrees')
for name,expected in json.loads((root/'MANIFEST_SHA256.json').read_text()).items():
    check((root/name).is_file() and hashlib.sha256((root/name).read_bytes()).hexdigest()==expected,'SHA256 '+name)

report=dict(result='PASS' if not errors else 'FAIL',checks_passed=len(checks),errors=errors,csv_row_counts={name:len(rows) for name,rows in tables.items()},limitations=['Mechanical checks do not prove legal completeness or current fee validity.','Source availability, live applications, phone operation, geographic boundaries and named human review not independently tested.','Semantic conflicts and missing facts remain in data_gaps.csv and data_quality_report.csv.'])
(root/'VALIDATION_REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
sys.exit(bool(errors))
