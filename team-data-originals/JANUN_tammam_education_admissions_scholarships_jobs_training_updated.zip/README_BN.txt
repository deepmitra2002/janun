JANUN — শিক্ষা, ভর্তি, বৃত্তি, চাকরি ও প্রশিক্ষণ
যাচাই: 2026-10-12 (বাংলাদেশ সময়)

মূল ৪০টি সেবা এবং সব ID/উৎস রাখা হয়েছে; ৩টি নতুন সেবা। programs.csv হলো JANUN import-এর জন্য সতর্ক normalized view; services.csv-এ মূল বিস্তারিত narrative ও নতুন verified_* / current_* ঘর আছে। শুধুমাত্র verified_fields ও সংশ্লিষ্ট source_id দেখে বর্তমান তথ্য দেখান। source_checked_date/collected_date মানে মানব যাচাই হয়েছে নয়; মূল verified_date ঘর অপরিবর্তিত।

status/application_status/recruitment_status সুযোগের অবস্থা; verification_status তথ্যের প্রমাণের অবস্থা। open ব্যবহার করতে verified source, সঠিক cycle এবং ভবিষ্যৎ deadline মিলতে হবে। unknown মানে ঘোষণা হয়নি এমন নিশ্চিত দাবি নয়, বরং এই অনুসন্ধানে নিশ্চিত নয়। closed/historical আগের চক্রের জন্য।

ফাইল: services/programs — সেবা; admissions — আলাদা cycle/unit; scholarships — recurring scheme ও নির্দিষ্ট window; jobs — ৫১তম বিশেষ BCS-এর দুই পৃথক post (একই circular); training_programs — recurring discovery route, বর্তমান batch নয়; institutions — DTE/BOU directory ও দুই বিশ্ববিদ্যালয়ের পরিচয়; exam_services — board-specific সেবা; education_boards_directory — ১১ বোর্ড; contact_points — প্রকাশিত যোগাযোগ; application_portals — official routes; sources — মূল ও নতুন উৎস; data_gaps/checklist — বাকি কাজ; coverage/district_coverage — ভৌগোলিক সীমা; data_quality/audit/url_check/resolved_fields/dataset_summary — যাচাই ও পরিবর্তনের হিসাব।

মূল Excel, JSON, README ও CSV originals/ ফোল্ডারে byte-for-byte আছে। পুরনো Excel/README-এর open/upcoming দাবি latest নয়। নতুন JSON দুইভাবে আছে: মূল nested structure-এ janun_tammam_services.json এবং সব টেবিলসহ janun_data.json।

যাচাইকৃত পরিচয়/ঠিকানা/website মানে সব কোর্স, fee, আসন বা ফোন সচল নিশ্চিত নয়। DTE তালিকার নাম/জেলা/website নেওয়া হয়েছে; বাংলা নাম, EIIN, ফোন, ঠিকানা/coordinates অজানা হলে ফাঁকা। JANUN- prefixed institution_id স্থানীয় stable ID, সরকারি code নয়। BOU নম্বর অনেক ক্ষেত্রে পুরোনো/সংক্ষিপ্ত; country/area code অনুমান করা হয়নি। Bilingual phone conflict আলাদা note-এ আছে।

PMEAT ভর্তি সহায়তার ২০২৬ হার নিশ্চিত; একই portal-এ payment timeline ৩০ কর্মদিবস বনাম ৪-৬ মাস দ্বন্দ্ব আছে। Medical grant helpdesk ৪টা বনাম ৫টা দ্বন্দ্ব আছে। সব future DU/GST alert স্বয়ংক্রিয়ভাবে current বলা হয়নি। BOU SSC/MBA নতুন cycle পৃথক; বিস্তারিত original circular অনুসরণ করুন।

সব CSV UTF-8 BOM; source IDs সেমিকোলন দিয়ে পৃথক। ফোন, ID, code text হিসেবে import করুন। ফাঁকা মান অজানা/প্রযোজ্য নয়; শূন্য/বিনামূল্য হিসেবে ধরবেন না। আগে সংরক্ষিত খসড়া paragraphs দিয়ে স্বয়ংক্রিয় eligibility decision করবেন না।

সীমা: পূর্ণ বাংলাদেশ স্কুল/কলেজ/বিশ্ববিদ্যালয়/BMET directory নেই; medical/GST/NU/private university current circular অসম্পূর্ণ; scholarship window/primary stipend/disability rates অসম্পূর্ণ; এক BCS circular ছাড়া live vacancy collection সম্পূর্ণ নয়; current training batch যাচাই হয়নি। Deadline-sensitive record প্রতিবার উত্তর দেওয়ার আগে current notice পরীক্ষা করুন; directory contact নিয়মিত পুনরায় যাচাই করুন।
